import express from 'express'

import ChatBot from '../models/chatBotModels.js'

import { isAdmin, isAuth } from '../utils.js'


const chatBotRouter = express.Router()



/** registrar consulta
 * este endpoint registra una consulta resuelta lo que significa que -
 * se registrar como resuelta solo si el chatbot termina todo su flujo
 */
chatBotRouter.post('/register-resuelta', async(req,res)=>{

    console.log('endpoint register a noresuelta consulta')

    try {


        const newChatbot = new ChatBot(req.body)
   
        const result = await newChatbot.save()
        res.json(result)
        
    } catch (error) {
        console.log(error)
        res.json({message:'hubo un error en el servidor'})
    }

})




chatBotRouter.get('/get-consultas', async (req, res) => {
    try {
        const { fecha1, fecha2, fecha3 } = req.query;

        // Recoge las fechas presentes en la consulta
        const fechas = [fecha1, fecha2, fecha3].filter(Boolean);

        if (fechas.length === 0) {
            return res.status(400).json({ message: 'Al menos una fecha debe ser proporcionada' });
        }

        console.log(fechas);

        const counts = await Promise.all(fechas.map(async (fecha) => {
            console.log(fecha)
            const count = await ChatBot.countDocuments({ createdAt: fecha });
            return { fecha, count };
        }));

        res.json(counts);
    } catch (error) {
        console.log(error);
        res.status(500).json({ message: 'Hubo un error en el servidor' });
    }
});

export default chatBotRouter