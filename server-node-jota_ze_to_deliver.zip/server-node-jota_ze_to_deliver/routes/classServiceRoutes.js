import express from 'express'
import ClassService from '../models/classServiceModels.js'
import { isAdmin, isAuth } from '../utils.js'
import User from '../models/userModels.js'


const classServiceRouter = express.Router()


// 
classServiceRouter.post('/create', async(req,res)=>{

    try {

        const newClassService = new ClassService(req.body)
        await newClassService.save()
        res.json({message:'clase de servicio agregado exitosamente'})
        
    } catch (error) {
        console.log(error)
        res.status(500).json({message:'hubo un error en el servidor'})
        
    }

})


//
classServiceRouter.get('/get-all-class-service', async(req,res)=>{

    try {
        const allClassService = await ClassService.find()
        res.json(allClassService)
    } catch (error) {
        console.log(error)
        res.status(500).json({message:'hubo un error en el servidor'})
    }

})


classServiceRouter.put('/update/:classServiceId', async(req,res)=>{

    try {

        const {classServiceId} = req.params
        await ClassService.findByIdAndUpdate(classServiceId, {...req.body})

        res.json({message:'servicio actualizado exitosamente'})

    } catch (error) {
        console.log(error)
        res.status(500).json({message:'hubo un error en el servidor'})
    }

})


classServiceRouter.delete('/delete/:classServiceId', async(req,res)=>{

    try {

        const {classServiceId} = req.params
        await ClassService.findByIdAndDelete(classServiceId)

        res.json({message:'servicio eliminado exitosamente'})

    } catch (error) {
        console.log(error)
        res.status(500).json({message:'hubo un error en el servidor'})
    }

})


export default classServiceRouter