import express from "express";
import bcryptjs from 'bcryptjs'
import nodemailer from 'nodemailer'

import User from "../models/userModels.js";
import generateJWT from "../helpers/generateJWT.js";
import { isAdmin, isAuth } from "../utils.js";

const userRouter = express.Router()


userRouter.post('/login', async(req,res)=>{
    console.log('endpint login')

    try {
         const {email,password} = req.body

        const isUserInDb = await User.findOne({email})

        if(!isUserInDb){
            return res.status(404).json({message:'Credenciales Incorrectas'})
        }

        //check if user is verified
		if (!isUserInDb.isVerified) {
			return res.status(400).json({ message: 'Tu Cuenta No Ha Sido Verificada' })
		}

        if(!bcryptjs.compareSync(password, isUserInDb.password)){
            return res.status(401).json({message:'Credenciales Incorrectas'})
        }

        const userAuthenticated = {
            email:isUserInDb.email,
            name:isUserInDb.nombres,
            role:isUserInDb.role,
            token:generateJWT(isUserInDb._id)
        }

        res.json(userAuthenticated)
    } catch (error) {
        console.log(error)
        res.json({message:'Hay un error en el servidor'})
    }

})


userRouter.post('/register-client', async (req, res) => {
    console.log('endpoint register client')
	const { nombres, email,dni, numeroRuc, password } = req.body

	console.log(numeroRuc)


	// using the real credentials to send emails
	var transport = nodemailer.createTransport({
		host: 'smtp.gmail.com',
		// port: 587,
		auth: {
			user: process.env.EMAIL_USER,
			pass: process.env.EMAIL_PASS,
		},
	});


	try {
		// Construir la consulta con $or
		let query = {
			$or: [
				{ email: email }
			]
		};

		// Solo agregar el campo numeroRuc a la consulta si se proporciona
		if (numeroRuc) {
			query.$or.push({ numeroRuc: numeroRuc });
		}

		if (dni) {
			query.$or.push({ dni: dni });
		}

		const isUserDb = await User.findOne(query);
		//checking if user already exist
		if (isUserDb) {
			return res.status(400).json({ message: 'Usuario Ya Registrado' })
		}

        const objNewUser = {
            ...req.body,
            password: password != '' ? bcryptjs.hashSync(password) : ''
        }

		// const newUser = new User({ name, email, password: password != '' ? bcryptjs.hashSync(password) : '' })
        const newUser = new User(objNewUser)
		newUser.token = Math.random().toString(32).substring(2) + Date.now().toString(32)
		await newUser.save()


		//enviando el correo
		const info = await transport.sendMail({
			from: 'Group Training Business <jota_ze@gmail.com>',
			to: email,
			subject: 'Proceso de confirmacion',
			text: 'Comprueba tu Cuenta de Group Training Business',
			html: `
            <p> Hola: ${nombres} Comprueba tu cuenta de Group Training Business </p>
            <p> Tu cuenta ya esta casi lista, solo debes comprobarla en el siguiente enlace: </p>

            <a href='${process.env.URL_VERIFIED_EMAIL_FRONTEND}/confirmaccount/${newUser.token}'>Comprobar Cuenta</a>
            <p> Si tu no creates esta cuenta, puedes ignorar el mensaje </p>
            `
		})

		console.log(info)

		res.json({ message: 'User succesfully created, Check your Email to confirm your account' })

	} catch (error) {
		console.log(error)
		//to check mongoose validation error like empty data
		if (error.name === "ValidationError") {
			let errors = [];

			Object.keys(error.errors).forEach((key) => {
				//   errors[key] = error.errors[key].message;
				errors.push(error.errors[key].message)
			});
			return res.status(400).send({ message: errors.join(' ||| ') });
		}

		res.status(500).send({ message: "Something went wrong" });

	}
})


//esta ruta solo admin tiene acceso para registrar users role user
userRouter.post('/register-user', async (req, res) => {
    console.log('endpoint register user')
	const { nombres, email, password } = req.body


	//definde and put credential using nodemailer to send emails
	// var transport = nodemailer.createTransport({
	// 	host: 'smtp.gmail.com',
	// 	// port: 587,
	// 	auth: {
	// 		user: process.env.EMAIL_USER,
	// 		pass: process.env.EMAIL_PASS,
	// 	},
	// });

    var transport = nodemailer.createTransport({
        host: "sandbox.smtp.mailtrap.io",
        port: 2525,
        auth: {
          user: "62138f4fc8d1d4",
          pass: "94c9ac5fb9f9cc"
        }
      });


	try {

		const isUserDb = await User.findOne({ email })

		//checking if user already exist
		if (isUserDb) {
			return res.status(400).json({ message: 'Usuario Ya Registrado' })
		}

        const objNewUser = {
            ...req.body,
            password: password != '' ? bcryptjs.hashSync(password) : '',
            role: 'user'
        }

		// const newUser = new User({ name, email, password: password != '' ? bcryptjs.hashSync(password) : '' })
        const newUser = new User(objNewUser)
		newUser.token = Math.random().toString(32).substring(2) + Date.now().toString(32)
		await newUser.save()


		//enviando el correo
		const info = await transport.sendMail({
			from: 'Group Training Business <jota_ze@gmail.com>',
			to: email,
			subject: 'Proceso de confirmacion',
			text: 'Comprueba tu Cuenta de Group Training Business',
			html: `
            <p> Hola: ${nombres} Comprueba tu cuenta de Group Training Business </p>
            <p> Tu cuenta ya esta casi lista, solo debes comprobarla en el siguiente enlace: </p>

            <a href='${process.env.URL_VERIFIED_EMAIL_FRONTEND}/confirmaccount/${newUser.token}'>Comprobar Cuenta</a>
            <p> Si tu no creates esta cuenta, puedes ignorar el mensaje </p>
            `
		})

		console.log(info)

		res.json({ message: 'User succesfully created, Check your Email to confirm your account' })

	} catch (error) {
		console.log(error)
		//to check mongoose validation error like empty data
		if (error.name === "ValidationError") {
			let errors = [];

			Object.keys(error.errors).forEach((key) => {
				//   errors[key] = error.errors[key].message;
				errors.push(error.errors[key].message)
			});
			return res.status(400).send({ message: errors.join(' ||| ') });
		}

		res.status(500).send({ message: "Something went wrong" });

	}
})


//this router is reach after you register a new email and go to your email and click the link
userRouter.get('/confirm/:tokenId', async (req, res) => {
	console.log('endpoint confirm account')
	const { tokenId } = req.params
	try {


		const isUser = await User.findOne({ token: tokenId })

		if (!isUser) {
			return res.status(400).json({ message: 'Token no Valido' })
		}

		isUser.isVerified = true
		isUser.token = ''
		await isUser.save()

		res.json({ message: 'Cuenta Confirmada Correctamente' })

	} catch (error) {
		console.log(error)
	}
})




///////////////////////////// role administrador y usuario

/** obtner todos los cientes que estan en la base de datos admin y user pueden ver
 * es para obtener la lista de clientes de la base de datos 
 * el role usuario podra ver todos los clientes pero no editar
 * el role admin podra ver todos los usuarios y tambien editarlos
 */
userRouter.get('/get-all-clients', isAuth,  async(req,res)=>{
	console.log('endpoint get all clients')
	try {

		const allClients = await User.find({role:'client'}).select('-password -token')

		res.json(allClients)
		
	} catch (error) {
		console.log(error)
		res.status(500).json({message:'hubo un error en el servidor'})
	}
})


/** editar clientes solo role admin puede hacerlo
 * este es para editar un cliente solo el role admin puede editar
 */
userRouter.put('/edit-client/:clientId',isAuth, isAdmin,  async(req,res)=>{

	try {
		const {clientId} = req.params

		console.log({...req.body})

		await User.findByIdAndUpdate(clientId, {...req.body})

		

		res.json({message:'cliente actualizado exitosamente'})

		
	} catch (error) {
		console.log(error)
		res.status(500).json({message:'hubo un error en el servidor'})
	}
})




///////////////// solo role administrador

/**buscar client ya sea por dni o rut
 * este parte es cuando el administrador solicita un servicio al cliente lo busca por dni o rut
 */
userRouter.get('/get-client/:param', isAuth, async(req,res)=>{
	console.log('endpoint get client by dni or rut')

    try {

        const {param} = req.params

		console.log(param)

		const query = {
            $or: [
                { dni: param },
                { numeroRuc: param }
            ]
        };

        const client = await User.findOne(query)


        res.json(client)
        
    } catch (error) {
        console.log(error)
        res.status(500).json({message:'500 Internal Server Error'})
    }

})


// es para obtener la lista de users en la base de datos solo admin puede verlos
userRouter.get('/get-all-users', isAuth, isAdmin, async(req,res)=>{
	console.log('endpoint get all suers')
	try {

		const allUsers = await User.find({role:'user'}).select('-password -token')

		res.json(allUsers)
		
	} catch (error) {
		console.log(error)
		res.status(500).json({message:'hubo un error en el servidor'})
	}
})


//este es para editar solo el admin podra editar a usuarios role user
userRouter.put('/edit-user/:userId',isAuth, isAdmin, async(req,res)=>{

	try {
		const {userId} = req.params

		await User.findByIdAndUpdate(userId, {...req.body})

		res.json({message:'usuario actualizado exitosamente'})
		
	} catch (error) {
		console.log(error)
		res.status(500).json({message:'hubo un error en el servidor'})
	}
})


export default userRouter