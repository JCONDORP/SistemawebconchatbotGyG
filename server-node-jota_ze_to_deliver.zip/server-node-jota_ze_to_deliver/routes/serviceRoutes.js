import express from "express";
import { upload } from "../helpers/multer.js";
import {
	cloudinaryDeleteOneFile,
	cloudinaryUploadFiles,
} from "../helpers/cloudinaryConfig.js";
import Service from "../models/serviceModels.js";
import { isAdmin, isAuth } from "../utils.js";
import User from "../models/userModels.js";

const serviceRouter = express.Router();

// esta ruta es publica
serviceRouter.get(
	"/search-service-by-no-solicitud/:numeroServicio",
	async (req, res) => {
		try {
			const { numeroServicio } = req.params;

			const isService = await Service.findOne({
				numeroServicio: numeroServicio,
			}).populate("encargado", "-password");

			if (!isService) {
				return res
					.status(404)
					.json({
						message: `No existe el numero ${numeroServicio} en la base de datos`,
					});
			}

			res.json(isService);
		} catch (error) {
			console.log(error);
			res.status(500).json({ message: "hubo un error en el servidor" });
		}
	}
);

////////////////// rutas privadas

/** este trae todos los servicios del cliente
 * este da todos los datos que se muestra en la opcion lista de servicios del frontend
 * solo del cliente y siendo modo cliente
 */
serviceRouter.get("/get-all-services-by-client", isAuth,  async (req, res) => {
	console.log('endpoint get all services by cliente role')
	try {
		const userId = req.user._id;

		const allServices = await Service.find({ clienteInfo: userId });

		res.json(allServices);
	} catch (error) {
		console.log(error);
		res.status(500).json({ message: "hubo un error en el servidor" });
	}
});


/** registrar servicio modo cliente
 * este endpoint es el formulario que se le presenta al cliente cuando se logea
 * sirve para solicitar un servicio teniendo role cliente
 */
serviceRouter.post("/register-service-client",isAuth,upload,async (req, res) => {
		console.log("endpoint register a service client mode");

		try {
			const files = req.files;

			req.body.clienteInfo = req.user._id;
			const newService = new Service(req.body);
			const cloudinaryResult = await cloudinaryUploadFiles(files, "jota_ze");

			newService.adjunto = cloudinaryResult;

			console.log(cloudinaryResult)

			await newService.save();
			res.json({ message: "servicio creado exitosamente" });
		} catch (error) {
			console.log(error);
			res.json({ message: "hubo un error en el servidor" });
		}
	}
);


/** registrar servicio modo admin o usuario
 * este endpoint es el formulario que se le presenta al admin o usuario
 * sirve para solicitarle un servicio al cliente cuando se es role admin o usuairo
 */
serviceRouter.post("/register-service-admin-user/:clientId",isAuth,upload,async (req, res) => {
		console.log("endpoint register a service admin/user mode");

		try {
			const { clientId } = req.params;

			const files = req.files;

			req.body.clienteInfo = clientId;
			req.body.encargado = req.user._id;
			const newService = new Service(req.body);
			const cloudinaryResult = await cloudinaryUploadFiles(files, "jota_ze");

			newService.adjunto = cloudinaryResult;

			// console.log(cloudinaryResult)

			await newService.save();
			res.json({ message: "servicio creado exitosamente" });
		} catch (error) {
			console.log(error);
			res.json({ message: "hubo un error en el servidor" });
		}
	}
);

/**este es el de editar servicios ya sea los inputs o el archivo
 * este funciona para todos los roles
 */
serviceRouter.put("/edit-service/:serviceId",isAuth,upload,async (req, res) => {
		console.log("endpoint edit a service");
		try {
			const files = req.files;
			const { serviceId } = req.params;

			if (files.length > 0) {
				const isService = await Service.findById(serviceId);
				const fileToDelete = isService.adjunto;
				const cloudinaryResult = await cloudinaryUploadFiles(files, "jota_ze");
				for (const item of fileToDelete) {
					console.log(item.cloudinary_id);
					await cloudinaryDeleteOneFile(item.cloudinary_id);
				}
				req.body.adjunto = cloudinaryResult;
			}

			await Service.findByIdAndUpdate(serviceId, { ...req.body });

			res.send("working");
		} catch (error) {
			console.log(error);
			res.status(500).json({ message: "hubo un error" });
		}
	}
);



//////////////// solo role admin y user

/** este se usara como select en el frontend
 * este endoint se usara en el formulario de derivar como select asi podra eligir user para derivar servicio
 */
serviceRouter.get("/get-all-user-and-admin", isAuth, async (req, res) => {
	console.log("endpoint get all user and admin");
	try {
		//extra validacion para asegurar que nadie que no sea admin o user vea la informacion
		if (req.user.role == "client") {
			return res
				.status(403)
				.json({
					message: "no tienes privilegios para obtener esta informacion",
				});
		}

		const users = await User.find({ role: { $in: ["admin", "user"] } }).select(
			"nombres"
		);

		res.json(users);
	} catch (error) {
		console.log(error);
		res.status(500).json({ message: "hubo un error en el seridor" });
	}
});



/** aqui ya podras derivar el servicio a otra usuario
 * y asi cambiar el estado de pendiente a derivado
 * en el request body viene el id de la persona a derivar
 */
serviceRouter.patch("/derivar-service/:serviceId", isAuth, async (req, res) => {
	console.log("endpoint derivar servicio");
	try {
		//extra validacion para asegurar que nadie que no sea admin o user vea la informacion
		if (req.user.role == "client") {
			return res
				.status(403)
				.json({
					message: "no tienes privilegios para obtener esta informacion",
				});
		}
		const { serviceId } = req.params;
		req.body.estado = "derivado";
		await Service.findByIdAndUpdate(serviceId, { ...req.body });
		res.json({ message: "servicio derivado exitosamente" });
	} catch (error) {
		console.log(error);
		res.status(500).json({ message: "hubo un error en el servidor" });
	}
});



/** este es para marcar un servicio como recibido
 * 
 */
serviceRouter.patch('/recibir-service/:serviceId', isAuth, async(req,res)=>{
	console.log('endpoint recibir servicio')
	try {

		const {serviceId} = req.params

		const isService = await Service.findById(serviceId)

		if(!isService){
			return res.status(404).json({message:'servicio no encontrado'})
		}

		isService.estado = 'recibido'

		await isService.save()

		res.json({message:'estatus cambiado exitosamente'})
		

	} catch (error) {
		console.log(error)
		res.status(500).json({message:'hubo un error en el servidor'})
	}

})

/** rechazar un servicio role user y admin puden rechazar
 * 
 */
serviceRouter.patch('/rechazar-service/:serviceId', isAuth, async(req,res)=>{
	console.log('endpoint recibir servicio')
	try {

		const {serviceId} = req.params

		const isService = await Service.findById(serviceId)

		if(!isService){
			return res.status(404).json({message:'servicio no encontrado'})
		}

		isService.estado = 'rechazado'

		await isService.save()

		res.json({message:'estatus cambiado exitosamente'})
		

	} catch (error) {
		console.log(error)
		res.status(500).json({message:'hubo un error en el servidor'})
	}

})


/** este es para marcar el servicio como atendido
 * en el req body viene la informacion estado a atendido y viene la fecha de finalizacion 
 * el campo de la fecha se llama fechaHoraFin
 */
serviceRouter.patch("/atendido-service/:serviceId", isAuth, async (req, res) => {
	console.log("endpoint derivar servicio");
	try {

		//extra validacion para asegurar que nadie que no sea admin o user vea la informacion
		if (req.user.role == "client") {
			return res
				.status(403)
				.json({
					message: "no tienes privilegios para obtener esta informacion",
				});
		}


		const { serviceId } = req.params;

		
		await Service.findByIdAndUpdate(serviceId, { ...req.body });
		res.json({ message: "estatus cambiado exitosamente" });
	} catch (error) {
		console.log(error);
		res.status(500).json({ message: "hubo un error en el servidor" });
	}
});



////////////////// solo role user

/** esta va en la parte de lista se servicios del frontend solo role user
 * 
 */
serviceRouter.get("/get-all-services-by-user", isAuth, async (req, res) => {
    try {
        const userId = req.user._id;

		// extra validacion que solo permite que el role user tenga acceso
		if(req.user.role !== 'user'){
			return res.status(403).json({message:'No tienes los suficientes privilegios'})
		}


        // Buscar servicios donde el usuario es el encargado y el estado no es pendiente
        const userServices = await Service.find({
            encargado: userId,
            estado: { $ne: 'pendiente' }
        })
        .populate('clienteInfo', '-_id -password') // Populate para obtener información del cliente, excluyendo _id y password
        .sort({ fechaHoraAccion: -1 }) // Ordenar por fechaHoraAccion en orden descendente
        // .select('-adjunto'); // Excluir el campo adjunto

      

        res.json(userServices);
    } catch (error) {
        console.log(error);
        res.status(500).json({ message: "hubo un error en el servidor" });
    }
});




///////////////// solo role administrador

/** lista de servicios pero modo administrador
 * esta es la parte de lista de servicios donde el admin mira toda la lista de los servicios
 * y el cliente asociado
 */
serviceRouter.get("/get-all-services", isAuth, isAdmin, async (req, res) => {
	try {
		const allServices = await Service.find().populate({
			path: "clienteInfo",
			select: "-password -token -isVerified",
		});

		res.json(allServices);
	} catch (error) {
		console.log(error);
		res.json({ message: "hubo un error en el servidor" });
	}
});




/** servicios por usuario
 * esta es la parte de reportes la que dice servicios por ususario
 */
serviceRouter.get("/get-servicios-por-usuario", async (req, res) => {
	try {
		const serviceByUsers = await Service.aggregate([
			{
				$lookup: {
					from: 'users', // Asumiendo que la colección de encargados se llama 'users'
					localField: 'encargado',
					foreignField: '_id',
					as: 'encargado'
				}
			},
			{
				$unwind: '$encargado'
			},
			{
				$sort: {
					'encargado.nombres': 1 // Orden ascendente por name de encargado
				}
			},
			{
				$project: {
					'adjunto': 0 // Excluir el campo adjunto
				}
			}
		]);

		res.json(serviceByUsers);
	} catch (error) {
		console.log(error);
		res.status(500).json({ message: "hubo un error en el servidor" });
	}
});



/**servicios por cliente atendido */
serviceRouter.get("/get-servicios-por-cliente", async (req, res) => {
    try {
        const serviceByUsers = await Service.aggregate([
            {
                $match: {
                    estado: "atendido"
                }
            },
            {
                $lookup: {
                    from: 'users', // Asumiendo que la colección de encargados se llama 'users'
                    localField: 'clienteInfo',
                    foreignField: '_id',
                    as: 'clienteInfo'
                }
            },
            {
                $unwind: '$clienteInfo'
            },
            {
                $sort: {
                    'clienteInfo.nombreRazonSocial': 1 // Orden ascendente por nombreRazonSocial del cliente
                }
            },
            {
                $project: {
                    'adjunto': 0 // Excluir el campo adjunto
                }
            }
        ]);

        res.json(serviceByUsers);
    } catch (error) {
        console.log(error);
        res.status(500).json({ message: "hubo un error en el servidor" });
    }
});



export default serviceRouter;
