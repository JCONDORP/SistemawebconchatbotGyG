import mongoose from "mongoose";

const {Schema} = mongoose


const chatBotSchema = new Schema({


    resuelta:{type:String},

    noResuelta:{type:String},

    createdAt:{type:String}



})


const ChatBot = mongoose.model('ChatBot', chatBotSchema)
export default ChatBot