import mongoose from "mongoose";

const {Schema} = mongoose

const serviceSchema = new Schema({

    numeroServicio: {type:String}, 

    codigo:{type:String},  

    tipoServicio:{type:String},

    servicio:{type:String},

    clienteInfo: {
        type: Schema.Types.ObjectId,
        ref: 'User'
    }, 

    encargado:{
        type:Schema.Types.ObjectId,
        ref:'User'
    },

    detalle: {type:String},   

    adjunto: [{}],   

    fechaHoraAccion: {type:String},

    fechaHoraFin: {type:String},

    estado: {type:String, default:'pendiente'},  //pendiente,derivado,recibido,rechazado,atendido 

    observacion : {type:String}



})



const Service = mongoose.model('Service', serviceSchema)
export default Service
