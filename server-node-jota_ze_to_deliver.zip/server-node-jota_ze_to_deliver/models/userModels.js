import mongoose from "mongoose";

const {Schema} = mongoose

const userSchema = new Schema({

    tipoPersona: {type:String}, //  tipo_usuairo = natural / juridica

    dni:{type:String},  //user,  tipo_usuairo =natural
    numeroRuc:{type:String}, //tipo_usuairo =juridica

    nombres: {type:String}, //user, tipo_usuairo =natural
    apellidos: {type:String},   //user, tipo_usuairo =natural

    nombreRazonSocial: {type:String},   //tipo_usuairo =juridica

    fechaNacimiento: {type:String}, //user, tipo_usuairo =natural

    email: {type:String},   //user, tipo_usuairo =natural / juridica

    numeroCelular:{type:String},    //user, tipo_usuairo =natural / juridica

    password: {type:String},    //user, tipo_usuairo =natural / juridica

    role:{type:String, default:'client'}, //tipo_usuairo =admin / user /client
    token: { type: String },

    isVerified: { type: Boolean, default: false },

})



const User = mongoose.model('User', userSchema)
export default User
