import mongoose from "mongoose";

const {Schema} = mongoose

const classServiceSchema = new Schema({

    claseServicio: {type:String}, 

    tipoServicio: [{}],   


})



const ClassService = mongoose.model('ClassService', classServiceSchema)
export default ClassService
